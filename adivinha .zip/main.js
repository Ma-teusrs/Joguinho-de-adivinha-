console.log('Hello World!');
let randomNumber = Math.floor(Math.random() * 100) + 1;
let guesses = 0;

function checkGuess() {
    let userGuess = Number(document.getElementById('guessField').value);
    let messageElement = document.getElementById('message');
    guesses++;

    if (userGuess === randomNumber) {
        messageElement.textContent = `Parabéns! Você acertou o número ${randomNumber} em ${guesses} tentativas.`;
        messageElement.style.color = 'green';
        disableInputAndButton();
    } else if (userGuess > randomNumber) {
        messageElement.textContent = 'Tente um número menor.';
        messageElement.style.color = 'red';
    } else {
        messageElement.textContent = 'Tente um número maior.';
        messageElement.style.color = 'red';
    }
}

function disableInputAndButton() {
    document.getElementById('guessField').disabled = true;
    document.querySelector('button').disabled = true;
}